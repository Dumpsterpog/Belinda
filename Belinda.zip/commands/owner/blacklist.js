const Discord = require('discord.js');
const db = require('quick.db');

module.exports = {
    name: "blacklistv13",

    run: async(client, message, args) => {
      
        let owner = [
            '772732775346208778',
            '788437792740081745'
        ]

        if (!owner.includes(message.author.id)){
          const embed = new Discord.MessageEmbed()
          .setTitle('This command is restricted for the dev/owner')
           return message.channel.send({ embeds: [embed] });
           
        }
        const user = message.mentions.users.first()
        if (!user)
        
          return message.reply('Please mention') 


        let blacklist = await db.fetch(`blacklist_${user.id}`)

        if (blacklist === 'Not'){
            await db.set(`blacklist_${user.id}`, "Blacklisted")
            const embed = new Discord.MessageEmbed()
            .setTitle(`User Blacklisted!`)
            .setDescription(`${user} has been blacklisted!`)
             return message.channel.send({ embeds: [embed] });
        } else if (blacklist === "Blacklisted"){
            await db.set(`blacklist_${user.id}`, "Not")
            const embed = new Discord.MessageEmbed()
            .setTitle(`User Unblacklisted!`)
            .setDescription(`${user} has been unblacklisted!`)
             return message.channel.send({ embeds: [embed] });
        } else {
            await db.set(`blacklist_${user.id}`, "Not")
            const embed = new Discord.MessageEmbed()
            .setTitle(`Set up data!`)
            .setDescription(`Adding user to db please try again!`)
             return message.channel.send({ embeds: [embed] });
        }

    }
}