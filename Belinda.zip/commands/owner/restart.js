module.exports = {
    name: "restart",
    aliases: ["res"],
    devOnly: true,
  run: async (client, message, args) => {
      
    if(message.author.id !== "772732775346208778") return message.reply({ content: ":x: | Only Bot Owners Can Use this Command!" });
        var spawn = require('child_process').spawn;

        await message.channel.send({ content: "Restarting bot.." });
        if (process.env.process_restarting) {
            delete process.env.process_restarting;
            return;
        }

        spawn(process.argv[0], process.argv.slice(1), {
            env: { process_restarting: 1 },
            stdio: 'ignore',
            detached: true
        }).unref();

        await message.reply({ content: "I have successfully restarted!" });
       
    },
};
/*module.exports = {
    name: "restart",
    aliases: ["res"],
    devOnly: true,
    async execute(message, args, data, client) {
        var spawn = require('child_process').spawn;

        await message.channel.send({ content: "Restarting bot.." });
        if (process.env.process_restarting) {
            delete process.env.process_restarting;
            return;
        }

        spawn(process.argv[0], process.argv.slice(1), {
            env: { process_restarting: 1 },
            stdio: 'ignore',
            detached: true
        }).unref();

        await message.reply({ content: "I have successfully restarted!" });
        process.exit();
    },
};*/